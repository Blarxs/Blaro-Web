FTBIY Cursor Pack v1.0

Thank you for downloading FTBIY Cursor Pack.

This cursor pack has been designed for Windows, aiming for a modern, clean and polished aesthetic, inspired by current cursor designs while maintaining its own unique style.

Pack Contents

The pack includes:

· Main Pointer
· Help
· Text
· Precision Select
· Busy
· Working in Background
· Link Select
· Person Select
· Location Select
· Handwriting
· Move
· Horizontal, vertical and diagonal resizing

Installation

1. Right-click the "install.inf" file.
2. Select "Install".
3. Open Windows Mouse Settings.
4. In the "Pointers" tab, select "FTBIY Cursor Pack v1.0".
5. Click "Apply".

Uninstallation

To return to the default Windows cursors:

1. Open Mouse Settings.
2. Go to the "Pointers" tab.
3. Select the default Windows scheme.
4. Click "Apply".

Credits

Cursor Design:
Blaro

Created with:
Affinity

Version

v1.0

Thank you for supporting the project.
